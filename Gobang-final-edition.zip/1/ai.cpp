#include "ai.h"
#include <QMessageBox>

AI::AI()
{
    for(int count_i=0; count_i<23; count_i++)
    {
        for(int count_j=0; count_j<23; count_j++)
        {
            a[count_i][count_j]=-1;
            //����23*23 broad ����Ϊ-1
        }
    }
    for(int count_i=4; count_i<19; count_i++)
    {
        for(int count_j=4; count_j<19; count_j++)
        {
            a[count_i][count_j]=0;
            //�м��15*15 ��������Ϊ0
        }
    }

    computery=0;
    computerx=0;
    humany=0;
    savey=0;
    humanx=0;
    savex=0;
}


int AI::Assess_live_three(int num)
{
    int score_live_three=0;
    int i=computerx;
    int j=computery;
        if(  a[i+1][j]==num &&  a[i+2][j]==num ) {
            if(a[i-1][j]==0 && a[i+3][j]==0) {
                score_live_three+=350+num*10;
            }
        } else if ( a[i-1][j]==num &&  a[i-2][j]==num ) {
            if(a[i+1][j]==0 && a[i-3][j]==0) {
                score_live_three+=350+num*10;
            }
        } else if( a[i-1][j]==num &&  a[i+1][j]==num) {
            if(a[i-2][j]==0 && a[i+2][j]==0) {
                score_live_three+=350+num*10;
            }
        }
        //ˮƽ����
        if(  a[i][j+1]==num &&  a[i][j+2]==num ) {
            if(a[i][j-1]==0 && a[i][j+3]==0) {
                score_live_three+=350+num*10;
            }
        } else if ( a[i][j-1]==num &&  a[i][j-2]==num ) {
            if(a[i][j+1]==0 && a[i][j-3]==0) {
                score_live_three+=350+num*10;
            }
        } else if( a[i][j-1]==num &&  a[i][j+1]==num) {
            if(a[i][j-2]==0 && a[i][j+2]==0) {
                score_live_three+=350+num*10;
            }
        }
        //б����һ
        if(  a[i+1][j+1]==num &&  a[i+2][j+2]==num ) {
            if(a[i-1][j-1]==0 && a[i+3][j+3]==0) {
                score_live_three+=350+num*10;
            }
        } else if ( a[i-1][j-1]==num &&  a[i-2][j-2]==num ) {
            if(a[i+1][j+1]==0 && a[i-3][j-3]==0) {
                score_live_three+=350+num*10;
            }
        } else if( a[i-1][j-1]==num &&  a[i+1][j+1]==num) {
            if(a[i-2][j-2]==0 && a[i+2][j+2]==0) {
                score_live_three+=350+num*10;
            }
        }
        //б�����
        if(  a[i+1][j-1]==num &&  a[i+2][j-2]==num ) {
            if(a[i-1][j+1]==0 && a[i+3][j-3]==0) {
                score_live_three+=350+num*10;
            }
        } else if ( a[i-1][j+1]==num &&  a[i-2][j+2]==num ) {
            if(a[i+1][j-1]==0 && a[i-3][j+3]==0) {
                score_live_three+=350+num*10;
            }
        } else if( a[i-1][j+1]==num &&  a[i+1][j-1]==num) {
            if(a[i-2][j+2]==0 && a[i+2][j-2]==0) {
                score_live_three+=350+num*10;
            }
        }

        return score_live_three;
}
int AI::Assess_live_two(int num)
{
    int score_live_two=0;
    int i=computerx;
    int j=computery;
        //ˮƽ����
        if(a[i][j+1]==num && a[i][j+2]==0 && a[i][j-1]==0) {
            if(a[i][j+3]==0 || a[i][j-2]==0) {
                score_live_two+=50+num*10;
            }
        } else if(a[i][j-1]==num && a[i][j-2]==0 && a[i][j+1]==0) {
            if(a[i][j-3]==0 || a[i][j+2]==0) {
                score_live_two+=50+num*10;
            }
        }
        //��ֱ����
        if(a[i+1][j]==num && a[i+2][j]==0 && a[i-1][j]==0) {
            if(a[i+3][j]==0 || a[i-2][j]==0) {
                score_live_two+=50+num*10;
            }
        } else if(a[i-1][j]==num && a[i-2][j]==0 && a[i+1][j]==0) {
            if(a[i-3][j]==0 || a[i+2][j]==0) {
                score_live_two+=50+num*10;
            }
        }
        //б����һ
        if(a[i+1][j+1]==num && a[i+2][j+2]==0 && a[i-1][j-1]==0) {
            if(a[i+3][j+3]==0 || a[i-2][j-2]==0) {
                score_live_two+=50+num*10;
            }
        } else if(a[i-1][j-1]==num && a[i-2][j-2]==0 && a[i+1][j+1]==0) {
            if(a[i-3][j-3]==0 || a[i+2][j+2]==0) {
                score_live_two+=50+num*10;
            }
        }
        //б�����
        if(a[i+1][j-1]==num && a[i+2][j-2]==0 && a[i-1][j+1]==0) {
            if(a[i+3][j-3]==0 || a[i-2][j+2]==0) {
                score_live_two+=50+num*10;
            }
        } else if(a[i-1][j+1]==num && a[i-2][j+2]==0 && a[i+1][j-1]==0) {
            if(a[i-3][j+3]==0 || a[i+2][j-2]==0) {
                score_live_two+=50+num*10;
            }
        }
        return score_live_two;
}

int AI::Assess_live_rush_four(int num)
{
    int score_live_rush_four=0;
    int i=computerx,j=computery;

    if(  a[i+1][j]==num &&  a[i+2][j]==num && a[i+3][j]==num) {
        if(a[i-1][j]==0 && a[i+4][j]==0) {
            score_live_rush_four+=1000;
        } else if (a[i-1][j]==0 || a[i+4][j]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if ( a[i-1][j]==num &&  a[i-2][j]==num && a[i-3][j]==num) {
        if(a[i+1][j]==0 && a[i-4][j]==0) {
            score_live_rush_four+=1000;
        } else	if(a[i+1][j]==0 || a[i-4][j]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if( a[i-1][j]==num &&  a[i+1][j]==num && a[i+2][j]==num) {
        if(a[i-2][j]==0 && a[i+3][j]==0) {
            score_live_rush_four+=1000;
        } else if(a[i-2][j]==0 || a[i+3][j]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if( a[i+1][j]==num &&  a[i-1][j]==num && a[i-2][j]==num) {
        if(a[i+2][j]==0 && a[i-3][j]==0) {
            score_live_rush_four+=1000;
        } else if(a[i+2][j]==0 || a[i-3][j]==0) {
            score_live_rush_four+=350+num*10;
        }
    }
    //ˮƽ����
    if(  a[i][j+1]==num &&  a[i][j+2]==num && a[i][j+3]==num) {
        if(a[i][j-1]==0 && a[i][j+4]==0) {
            score_live_rush_four+=1000;
        } else if(a[i][j-1]==0 || a[i][j+4]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if ( a[i][j-1]==num &&  a[i][j-2]==num && a[i][j-3]==num) {
        if(a[i][j+1]==0 && a[i][j-4]==0) {
            score_live_rush_four+=1000;
        } else if(a[i][j+1]==0 || a[i][j-4]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if( a[i][j-1]==num &&  a[i][j+1]==num && a[i][j+2]==num) {
        if(a[i][j-2]==0 && a[i][j+3]==0) {
            score_live_rush_four+=1000;
        } else if(a[i][j-2]==0 || a[i][j+3]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if( a[i][j+1]==num &&  a[i][j-1]==num && a[i][j-2]==num) {
        if(a[i][j+2]==0 && a[i][j-3]==0) {
            score_live_rush_four+=1000;
        } else if(a[i][j+2]==0 || a[i][j-3]==0) {
            score_live_rush_four+=350+num*10;
        }
    }
    //б����һ
    if(  a[i+1][j+1]==num &&  a[i+2][j+2]==num && a[i+3][j+3]==num) {
        if(a[i-1][j-1]==0 && a[i+4][j+4]==0) {
            score_live_rush_four+=1000;
        } else if(a[i-1][j-1]==0 || a[i+4][j+4]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if ( a[i-1][j-1]==num &&  a[i-2][j-2]==num && a[i-3][j-3]==num) {
        if(a[i+1][j+1]==0 && a[i-4][j-4]==0) {
            score_live_rush_four+=1000;
        } else if(a[i+1][j+1]==0 || a[i-4][j-4]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if( a[i-1][j-1]==num &&  a[i+1][j+1]==num && a[i+2][j+2]==num) {
        if(a[i-2][j-2]==0 && a[i+3][j+3]==0) {
            score_live_rush_four+=1000;
        } else if(a[i-2][j-2]==0 || a[i+3][j+3]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if( a[i+1][j+1]==num &&  a[i-1][j-1]==num && a[i-2][j-2]==num) {
        if(a[i+2][j+2]==0 && a[i-3][j-3]==0) {
            score_live_rush_four+=1000;
        } else if(a[i+2][j+2]==0 || a[i-3][j-3]==0) {
            score_live_rush_four+=350+num*10;
        }
    }
    //б�����
    if(  a[i+1][j-1]==num &&  a[i+2][j-2]==num && a[i+3][j-3]==num) {
        if(a[i-1][j+1]==0 && a[i+4][j-4]==0) {
            score_live_rush_four+=1000;
        } else if(a[i-1][j+1]==0 || a[i+4][j-4]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if ( a[i-1][j+1]==num &&  a[i-2][j+2]==num && a[i-3][j+3]==num) {
        if(a[i+1][j-1]==0 && a[i-4][j+4]==0) {
            score_live_rush_four+=1000;
        } else if(a[i+1][j-1]==0 || a[i-4][j+4]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if( a[i-1][j+1]==num &&  a[i+1][j-1]==num && a[i+2][j-2]==num) {
        if(a[i-2][j+2]==0 && a[i+3][j-3]==0) {
            score_live_rush_four+=1000;
        } else if(a[i-2][j+2]==0 || a[i+3][j-3]==0) {
            score_live_rush_four+=350+num*10;
        }
    } else if( a[i+1][j-1]==num &&  a[i-1][j+1]==num && a[i-2][j+2]==num) {
        if(a[i+2][j-2]==0 && a[i-3][j+3]==0) {
            score_live_rush_four+=1000;
        } else if(a[i+2][j-2]==0 || a[i-3][j+3]==0) {
            score_live_rush_four+=350+num*10;
        }
    }

    return score_live_rush_four;
}



AI::~AI()
{
}



void AI::Machine_easy()
{
    int score_machine_max=0,score_human_max=0;
    int set_machine_i,set_machine_j,
            set_human_i,set_human_j,
            score_machine,score_human,i,j;
int latest_score_machine_max=0,latest_score_machine_max_human=0;
        //�������������Ӯ����ôΪÿһ�����������ӵĵط�����������С��
        //���ѡ��������ߵģ�Ŀǰ�����ߵ�ȡ���һ�����Ժ���������޸�
    if(Whether_win(2)) {
            ;											//�����ж��Ƿ�����Ѿ�����Ӯ�ˣ�������� ֱ�Ӹ�ֵ������2��������������һ��
        } else if(Whether_win(1)) {
            ;
    } else {
        for(i=4; i<19; i++)
        {
            for(j=4; j<19; j++)
            {
                if(a[i][j]==0)
                {
                    if(a[i][j]==1)
                    {
                        continue;
                    }
                    else if(a[i][j]==2)
                    {
                        continue;
                    }
                    humanx=i;
                    humany=j;
                    computerx=i;
                    computery=j;
                    score_machine=Assess_live_three(2)+Assess_live_rush_four(2)+Assess_live_two(2);
                     score_human=Assess_live_three(1)+Assess_live_rush_four(1)+Assess_live_two(1);

                     if(score_machine>score_machine_max) {	//�����Ƿ��������������жϷ�ֵ��ͬ�ص�
                         score_machine_max=score_machine;
                              set_machine_i=i;
                               set_machine_j=j;
                             latest_score_machine_max=score_machine;
                             latest_score_machine_max_human=score_human;
                      } else if(score_machine==score_machine_max) {
                            if(score_machine+score_human>latest_score_machine_max+latest_score_machine_max_human) {
                            score_machine_max=score_machine;
                                 set_machine_i=i;
                               set_machine_j=j;
                             latest_score_machine_max=score_machine;
                                  latest_score_machine_max_human=score_human;
                                  }
                       }
                         if(score_human>score_human_max) {
                                     //�����Ƿ�����������ҷ�ֵ��ͬ��
                                score_human_max=score_human;
                               set_human_i=i;
                              set_human_j=j;
                           }
                }
            }
        }

        if(latest_score_machine_max>=1000) {
                        a[set_machine_i][set_machine_j]=2;

                        computerx=set_machine_i;
                        computery=set_machine_j;
                    } else if(score_human_max>latest_score_machine_max_human+latest_score_machine_max) { 								//����߷����뼰����߷���Ƚ�
                        a[set_human_i][set_human_j]=2;										//����ԭ����ǿ�Ҷ£���ǿ���
                        computerx=set_human_i;
                        computery=set_human_j;
                    } else {
                        a[set_machine_i][set_machine_j]=2;

                        computerx=set_machine_i;
                        computery=set_machine_j;
                    }

    }

}
void AI::sethumanx(int hx)
{
    humanx=hx;
    savex=hx;
}
void AI::sethumany(int hy)
{
    humany=hy;
    savey=hy;
}

int AI::Whether_win(int num)
{
    int flag_win=0,i,j;
    for(i=4; i<19; i++)
    {
        for(j=4; j<19; j++)
        {
            if(a[i][j]==0)
            {	//ˮƽ����
                if (a[i+1][j]==num && a[i+2][j]==num && a[i+3][j]==num &&a[i+4][j]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i-1][j]==num && a[i-2][j]==num && a[i-3][j]==num &&a[i-4][j]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i-1][j]==num && a[i-2][j]==num && a[i+1][j]==num &&a[i+2][j]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i-1][j]==num && a[i-2][j]==num && a[i-3][j]==num &&a[i+1][j]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i+1][j]==num && a[i+2][j]==num && a[i+3][j]==num &&a[i-1][j]==num)
                {
                    flag_win=1;
                    break;
                }
                //��ֱ����
                if (a[i][j+1]==num && a[i][j+2]==num && a[i][j+3]==num &&a[i][j+4]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i][j-1]==num && a[i][j-2]==num && a[i][j-3]==num &&a[i][j-4]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i][j-1]==num && a[i][j-2]==num && a[i][j+1]==num &&a[i][j+2]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i][j-1]==num && a[i][j-2]==num && a[i][j-3]==num &&a[i][j+1]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i][j+1]==num && a[i][j+2]==num && a[i][j+3]==num &&a[i][j-1]==num)
                {
                    flag_win=1;
                    break;
                }
                //б����һ
                if(a[i+1][j+1]==num && a[i+2][j+2]==num && a[i+3][j+3]==num &&a[i+4][j+4]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i-1][j-1]==num && a[i-2][j-2]==num && a[i-3][j-3]==num &&a[i-4][j-4]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i-1][j-1]==num && a[i-2][j-2]==num && a[i+1][j+1]==num &&a[i+2][j+2]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i-1][j-1]==num && a[i-2][j-2]==num && a[i-3][j-3]==num &&a[i+1][j+1]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i+1][j+1]==num && a[i+2][j+2]==num && a[i+3][j+3]==num &&a[i-1][j-1]==num)
                {
                    flag_win=1;
                    break;
                }
                //б�����
                if (a[i+1][j-1]==num && a[i+2][j-2]==num && a[i+3][j-3]==num &&a[i+4][j-4]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i-1][j+1]==num && a[i-2][j+2]==num && a[i-3][j+3]==num &&a[i-4][j+4]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i-1][j+1]==num && a[i-2][j+2]==num && a[i+1][j-1]==num &&a[i+2][j-2]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i-1][j+1]==num && a[i-2][j+2]==num && a[i-3][j+3]==num &&a[i+1][j-1]==num)
                {
                    flag_win=1;
                    break;
                }
                else if(a[i+1][j-1]==num && a[i+2][j-2]==num && a[i+3][j-3]==num &&a[i-1][j+1]==num)
                {
                    flag_win=1;
                    break;
                }
            }
        }

        if(flag_win==1)
        {
            a[i][j]=2;
           //�������һ�������i��j��
            computerx=i;
            computery=j;
            break;
        }
    }
    return flag_win;
}
void AI::Clear()
{
    for(int k1 = 0; k1<23; ++k1)                          //The segment can be simplified
    {
        for(int k2 = 0; k2<0; ++k2)
        {
            a[k1][k2] = -1;
        }
    }
    for(int k3 = 0; k3<15; k3++)                          //The segment can be simplified
    {
        for(int k4 = 0; k4<15; k4++)
        {
            a[k3+4][k4+4] = 0;
        }
    }
}

void AI::Game()
{

       //�������̣�ʹ�÷�����������

        a[savex+4][savey+4]=1;//�������

        Machine_easy();

        a[computerx][computery]=2;
}

