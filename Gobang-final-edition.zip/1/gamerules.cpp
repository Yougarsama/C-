#include "gamerules.h"
#include "ui_gamerules.h"

Gamerules::Gamerules(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Gamerules)
{
    ui->setupUi(this);
    setWindowTitle("Rules");//设置窗口标题
}

Gamerules::~Gamerules()
{
    delete ui;
}

void Gamerules::on_pushButton_clicked()
{
    MainWindow *c2=new MainWindow;
    c2->show();
    this->close();
}

