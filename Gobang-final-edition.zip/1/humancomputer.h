/*
#ifndef HUMANCOMPUTER_H
#define HUMANCOMPUTER_H

#include <QMainWindow>

namespace Ui {
class Humancomputer;
}

class Humancomputer : public QMainWindow
{
    Q_OBJECT

public:
    explicit Humancomputer(QWidget *parent = 0);
    ~Humancomputer();

private:
    Ui::Humancomputer *ui;
};

#endif // HUMANCOMPUTER_H
*/


#ifndef HUMANCOMPUTER_H
#define HUMANCOMPUTER_H

#include <QtWidgets/QMainWindow>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsItem>
#include <QMouseEvent>

#include "ai.h"

class Humancomputer : public QMainWindow
{
    Q_OBJECT

public:
    Humancomputer(QWidget *parent = 0);
    void mousePressEvent(QMouseEvent *);//��갴���¼�
    void drawCrossLine();//������
    void Win();//�ж���Ӯ
    int situation1();
    int situation2();
    int situation3();
    int situation4();
    AI *ai=new AI;
    ~Humancomputer();

private:
    QGraphicsScene *scene;
    QGraphicsView *view;
    QGraphicsItem *item;

    int player;
    int array[15][15];
};

#endif // MAINWINDOW_H
