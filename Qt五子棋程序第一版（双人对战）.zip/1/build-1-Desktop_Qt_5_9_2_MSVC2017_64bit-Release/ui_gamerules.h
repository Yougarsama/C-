/********************************************************************************
** Form generated from reading UI file 'gamerules.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GAMERULES_H
#define UI_GAMERULES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Gamerules
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QPushButton *pushButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Gamerules)
    {
        if (Gamerules->objectName().isEmpty())
            Gamerules->setObjectName(QStringLiteral("Gamerules"));
        Gamerules->resize(600, 800);
        Gamerules->setMinimumSize(QSize(600, 800));
        centralwidget = new QWidget(Gamerules);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(230, 120, 141, 51));
        label->setStyleSheet(QLatin1String("font: 20pt \"Arial\";\n"
"font: 28pt \"Arial\";"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(210, 600, 180, 35));
        pushButton->setStyleSheet(QStringLiteral("font: 14pt \"Arial\";"));
        Gamerules->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Gamerules);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 600, 26));
        Gamerules->setMenuBar(menubar);
        statusbar = new QStatusBar(Gamerules);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Gamerules->setStatusBar(statusbar);

        retranslateUi(Gamerules);

        QMetaObject::connectSlotsByName(Gamerules);
    } // setupUi

    void retranslateUi(QMainWindow *Gamerules)
    {
        Gamerules->setWindowTitle(QApplication::translate("Gamerules", "MainWindow", Q_NULLPTR));
        label->setText(QApplication::translate("Gamerules", "\350\257\267\347\231\276\345\272\246", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Gamerules", "\350\277\224\345\233\236", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Gamerules: public Ui_Gamerules {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GAMERULES_H
