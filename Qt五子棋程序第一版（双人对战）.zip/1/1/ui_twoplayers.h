/********************************************************************************
** Form generated from reading UI file 'twoplayers.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TWOPLAYERS_H
#define UI_TWOPLAYERS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Twoplayers
{
public:
    QWidget *centralwidget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Twoplayers)
    {
        if (Twoplayers->objectName().isEmpty())
            Twoplayers->setObjectName(QStringLiteral("Twoplayers"));
        Twoplayers->resize(600, 600);
        centralwidget = new QWidget(Twoplayers);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        Twoplayers->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Twoplayers);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 600, 26));
        Twoplayers->setMenuBar(menubar);
        statusbar = new QStatusBar(Twoplayers);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Twoplayers->setStatusBar(statusbar);

        retranslateUi(Twoplayers);

        QMetaObject::connectSlotsByName(Twoplayers);
    } // setupUi

    void retranslateUi(QMainWindow *Twoplayers)
    {
        Twoplayers->setWindowTitle(QApplication::translate("Twoplayers", "MainWindow", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Twoplayers: public Ui_Twoplayers {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TWOPLAYERS_H
