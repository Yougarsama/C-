#include "humancomputer.h"
#include "ui_humancomputer.h"

Humancomputer::Humancomputer(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Humancomputer)
{
    ui->setupUi(this);
}

Humancomputer::~Humancomputer()
{
    delete ui;
}
