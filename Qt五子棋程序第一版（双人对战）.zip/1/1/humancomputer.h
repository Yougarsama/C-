#ifndef HUMANCOMPUTER_H
#define HUMANCOMPUTER_H

#include <QMainWindow>

namespace Ui {
class Humancomputer;
}

class Humancomputer : public QMainWindow
{
    Q_OBJECT

public:
    explicit Humancomputer(QWidget *parent = 0);
    ~Humancomputer();

private:
    Ui::Humancomputer *ui;
};

#endif // HUMANCOMPUTER_H
