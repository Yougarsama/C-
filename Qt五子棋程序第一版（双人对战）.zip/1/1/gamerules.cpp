#include "gamerules.h"
#include "ui_gamerules.h"

Gamerules::Gamerules(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Gamerules)
{
    ui->setupUi(this);
}

Gamerules::~Gamerules()
{
    delete ui;
}

void Gamerules::on_pushButton_clicked()
{
    MainWindow *c2=new MainWindow;
    c2->show();
    this->close();
}
