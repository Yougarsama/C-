/********************************************************************************
** Form generated from reading UI file 'humancomputer.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HUMANCOMPUTER_H
#define UI_HUMANCOMPUTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Humancomputer
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Humancomputer)
    {
        if (Humancomputer->objectName().isEmpty())
            Humancomputer->setObjectName(QStringLiteral("Humancomputer"));
        Humancomputer->resize(600, 600);
        centralwidget = new QWidget(Humancomputer);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(180, 150, 231, 61));
        label->setStyleSheet(QStringLiteral("font: 28pt \"Arial\";"));
        Humancomputer->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Humancomputer);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 600, 26));
        Humancomputer->setMenuBar(menubar);
        statusbar = new QStatusBar(Humancomputer);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Humancomputer->setStatusBar(statusbar);

        retranslateUi(Humancomputer);

        QMetaObject::connectSlotsByName(Humancomputer);
    } // setupUi

    void retranslateUi(QMainWindow *Humancomputer)
    {
        Humancomputer->setWindowTitle(QApplication::translate("Humancomputer", "MainWindow", Q_NULLPTR));
        label->setText(QApplication::translate("Humancomputer", "\344\272\272\346\234\272\345\276\205\346\267\273\345\212\240", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Humancomputer: public Ui_Humancomputer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HUMANCOMPUTER_H
