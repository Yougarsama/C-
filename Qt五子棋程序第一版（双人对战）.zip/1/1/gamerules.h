#ifndef GAMERULES_H
#define GAMERULES_H

#include <QMainWindow>
#include "mainwindow.h"

namespace Ui {
class Gamerules;
}

class Gamerules : public QMainWindow
{
    Q_OBJECT

public:
    explicit Gamerules(QWidget *parent = 0);
    ~Gamerules();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Gamerules *ui;
};

#endif // GAMERULES_H
