/*
#ifndef TWOPLAYERS_H
#define TWOPLAYERS_H

#include <QMainWindow>

namespace Ui {
class Twoplayers;
}

class Twoplayers : public QMainWindow
{
    Q_OBJECT

public:
    explicit Twoplayers(QWidget *parent = 0);
    ~Twoplayers();

private:
    Ui::Twoplayers *ui;
};

#endif // TWOPLAYERS_H
*/

#ifndef TWOPLATERS_H
#define TWOPLATERS_H

#include <QtWidgets/QMainWindow>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsItem>
#include <QMouseEvent>

class Twoplayers : public QMainWindow
{
    Q_OBJECT

public:
    Twoplayers(QWidget *parent = 0);
    void mousePressEvent(QMouseEvent *);//��갴���¼�
    void drawCrossLine();//������
    void Win();//�ж���Ӯ
    int situation1();
    int situation2();
    int situation3();
    int situation4();
private:
    QGraphicsScene *scene;
    QGraphicsView *view;
    QGraphicsItem *item;
    int palyer;
    int a[15][15];
};

#endif // MAINWINDOW_H
