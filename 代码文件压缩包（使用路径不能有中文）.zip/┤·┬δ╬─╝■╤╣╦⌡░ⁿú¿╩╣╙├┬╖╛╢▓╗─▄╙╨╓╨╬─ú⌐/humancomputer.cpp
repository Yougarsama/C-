/*
#include "humancomputer.h"
#include "ui_humancomputer.h"

Humancomputer::Humancomputer(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Humancomputer)
{
    ui->setupUi(this);
}

Humancomputer::~Humancomputer()
{
    delete ui;
}
*/


#include "humancomputer.h"
#include <QMessageBox>
#include <QDebug>
#include "ai.h"

Humancomputer::Humancomputer(QWidget *parent)
    : QMainWindow(parent),ai(new AI)
{


    /*ergodic all the point,��ÿ������Ĭ��ֵ��Ϊ0, ����a�����������Ƿ�������*/
    for(int i = 0; i<15; ++i)
    {
        for(int j = 0; j<15; ++j)
        {
//            ai->a[i+4][j+4];
            array[i][j] = 0;
        }
    }



    player = 1;                                                 //��ʼ��
    setStatusBar(0);
    scene = new QGraphicsScene;
    scene->setSceneRect(-300, -300, 600, 600);                  //����two player ������С

    drawCrossLine();                                            //������

    view = new QGraphicsView;
    view->setBackgroundBrush(QColor(222, 184, 135));            //���ñ�����ɫ
    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff); //ȥ��QGraphicsView�Ĺ�����(two direction: horizon,vertical)
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setScene(scene);
    view->setRenderHint(QPainter::Antialiasing);                //���÷�����(�����)
    setCentralWidget(view);

    /*�̶���С*/
    setMaximumSize(600, 600);
    setMinimumSize(600, 600);
    setWindowTitle("Human vs Computer");//���ô��ڱ���

}

void Humancomputer::mousePressEvent( QMouseEvent *e )
{
    int x, y;
    int m, n;

    /*����¼�������ϵ��view,������scene*/
    if(e->x()<=300)
        x =(e->x()-300)/40 -1;
    else if(e->x()>300)
        x =(e->x()-300)/40;
    if(e->y()<=300)
        y = (e->y()-300)/40-1;
    else if(e->y()>300)
        y = (e->y()-300)/40;

    m = x+8;
    n = y+8;
//    QDebug qDebug();
    qDebug() << m << n << endl;/////////////////////////

    /*�����ǰ���������,��������*/
    if(array[m][n] != 0)
    {
        QMessageBox::warning(this, "warning", "This Position has Already had chess!", QMessageBox::Ok);

    }

    else
    {
        array[m][n] = 1;
        scene->addEllipse(40*x, 40*y, 35, 35, QPen(Qt::NoPen),QBrush(Qt::black));//����hei��
        player=2;//->COMPUTER

        ai->sethumanx(m);
        ai->sethumany(n);
        ai->Game();
//        qDebug() << ai->computery << ai->computery << endl;//////////////////////
        m=ai->computerx-4;
        n=ai->computery-4;
        qDebug() << m << n << endl;/////////////////////
        array[m][n] = 2;
        x=m-8;
        y=n-8;

        scene->addEllipse(40*x, 40*y, 35, 35, QPen(Qt::NoPen),QBrush(Qt::white));//����bai��
        player=1;//->HUMAN
    }

//        player = !player;//ת���ڰ�����


    Win();//�ж���Ӯ
}

void Humancomputer::drawCrossLine()
{
    for(int i = 0; i<15; ++i)
    {
        scene->addLine(-300, -300+40*i, 300, -300+40*i);
        scene->addLine(-300+40*i, -300, -300+40*i, 300);
    }
}

void Humancomputer::Win()                              //From different situations,judge win or not
{
    int okButton;
    if((situation1() ==1)
        ||(situation2() ==1)
        || (situation3() ==1)
        || (situation4() ==1))
    {
        okButton= QMessageBox::information(this, "win", "black win!", QMessageBox::Ok);
    }
    if((situation1() ==2)
        ||(situation2() ==2)
        || (situation3() ==2)
        || (situation4() ==2))
        okButton = QMessageBox::information(this, "win", "white win!", QMessageBox::Ok);

    if(okButton == QMessageBox::Ok)//show QMessageBox,begin the new game
    {
        /*�������*/
        ai->Clear();
        QList<QGraphicsItem*> list = scene->items();
        while(!list.empty())
        {
            scene->removeItem(list.at(0));
            list.removeAt(0);
        }
//        Humancomputer::~Humancomputer();
        /*��ʼ������*/
//        Humancomputer::Humancomputer();

        for(int i = 0; i<15; ++i)                          //The segment can be simplified
        {
            for(int j = 0; j<15; ++j)
            {
                array[i][j] = 0;
            }
        }

        player = 1;

        drawCrossLine();                                   //draw the broad
    }
}

int   Humancomputer::situation1()//������Ӻ���
{
    for(int i = 0; i< 15; ++i)                             //Judge win or not from the horizontal direction
        for(int j = 0; j<15; ++j)
        {
            if(i>=0 && i<11 && j >=0 &&j<15)
            {
                if(	array[i][j] == 1
                    &&array[i+1][j] == 1
                    &&array[i+2][j] == 1
                    &&array[i+3][j] == 1
                    &&array[i+4][j] == 1)
                    return 1;
                if(	array[i][j] == 2
                    &&array[i+1][j] == 2
                    &&array[i+2][j] == 2
                    &&array[i+3][j] == 2
                    &&array[i+4][j] == 2)
                    return 2;
            }
        }
        return 0;
}

int Humancomputer::situation2()//�����������
{
    for(int i = 0; i< 15; ++i)                              //Judge win or not from the vertical direction
        for(int j = 0; j<15; ++j)
        {
            if(i>=0 &&i<15 &&j>=0 &&j<11)
            {
                if(	array[i][j] == 1
                    &&array[i][j+1] == 1
                    &&array[i][j+2] == 1
                    &&array[i][j+3] == 1
                    &&array[i][j+4] == 1)
                    return 1;
                if(	array[i][j] == 2
                    &&array[i][j+1] == 2
                    &&array[i][j+2] == 2
                    &&array[i][j+3] == 2
                    &&array[i][j+4] == 2)
                    return 2;
            }
        }
        return 0;
}

int Humancomputer::situation3()//�����������б��
{
    for(int i = 0; i< 15; ++i)                              //Judge win or not from the "\" direction
        for(int j = 0; j<15; ++j)
        {
            if(i>=0&& i<11&&j>=4&&j<15)
            {
                if(	array[i][j] == 1
                    &&array[i+1][j-1] == 1
                    &&array[i+2][j-2] == 1
                    &&array[i+3][j-3] == 1
                    &&array[i+4][j-4] == 1)
                    return 1;
                if(	array[i][j] == 2
                    &&array[i+1][j-1] == 2
                    &&array[i+2][j-2] == 2
                    &&array[i+3][j-3] == 2
                    &&array[i+4][j-4] == 2)
                    return 2;
            }

        }
        return 0;
}

int Humancomputer::situation4()//�����������б��
{
    for(int i = 0; i< 15; ++i)//Judge win or not from the "/" direction
        for(int j = 0; j<15; ++j)
        {
            if(i>=0&& i<15&&j>=0&&j<11)
            {
                if(	array[i][j] == 1
                    &&array[i+1][j+1] == 1
                    &&array[i+2][j+2] == 1
                    &&array[i+3][j+3] == 1
                    &&array[i+4][j+4] == 1)
                    return 1;
                if(	array[i][j] == 2
                    &&array[i+1][j+1] == 2
                    &&array[i+2][j+2] == 2
                    &&array[i+3][j+3] == 2
                    &&array[i+4][j+4] == 2)
                    return 2;
            }
        }
        return 0;
}
Humancomputer::~Humancomputer()
{

}
