/********************************************************************************
** Form generated from reading UI file 'gamerules.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GAMERULES_H
#define UI_GAMERULES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Gamerules
{
public:
    QAction *actionMenu;
    QWidget *centralwidget;
    QLabel *label;
    QPushButton *pushButton;
    QLabel *label_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Gamerules)
    {
        if (Gamerules->objectName().isEmpty())
            Gamerules->setObjectName(QStringLiteral("Gamerules"));
        Gamerules->resize(600, 600);
        Gamerules->setMinimumSize(QSize(0, 0));
        actionMenu = new QAction(Gamerules);
        actionMenu->setObjectName(QStringLiteral("actionMenu"));
        centralwidget = new QWidget(Gamerules);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(230, 40, 131, 61));
        label->setStyleSheet(QLatin1String("font: 14pt \"Arial\";\n"
"font: 20pt \"Arial\";"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(210, 470, 180, 35));
        pushButton->setStyleSheet(QStringLiteral("font: 20pt \"Arial\";"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(90, 140, 421, 271));
        label_2->setStyleSheet(QStringLiteral("font: 14pt \"Arial\";"));
        Gamerules->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Gamerules);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 600, 26));
        Gamerules->setMenuBar(menubar);
        statusbar = new QStatusBar(Gamerules);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Gamerules->setStatusBar(statusbar);

        retranslateUi(Gamerules);

        QMetaObject::connectSlotsByName(Gamerules);
    } // setupUi

    void retranslateUi(QMainWindow *Gamerules)
    {
        Gamerules->setWindowTitle(QApplication::translate("Gamerules", "MainWindow", Q_NULLPTR));
        actionMenu->setText(QApplication::translate("Gamerules", "Menu", Q_NULLPTR));
        label->setText(QApplication::translate("Gamerules", "\346\270\270\346\210\217\350\247\204\345\210\231", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Gamerules", "\350\277\224\345\233\236", Q_NULLPTR));
        label_2->setText(QApplication::translate("Gamerules", "\344\272\224\345\255\220\346\243\213\346\230\257\344\270\226\347\225\214\346\231\272\345\212\233\350\277\220\345\212\250\344\274\232\347\253\236\346\212\200\351\241\271\347\233\256\344\271\213\344\270\200\357\274\214\n"
"\346\230\257\344\270\200\347\247\215\344\270\244\344\272\272\345\257\271\345\274\210\347\232\204\347\272\257\347\255\226\347\225\245\345\236\213\346\243\213\347\261\273\346\270\270\346\210\217\357\274\214\n"
"\351\200\232\345\270\270\345\217\214\346\226\271\345\210\206\345\210\253\344\275\277\347\224\250\351\273\221\347\231\275\344\270\244\350\211\262\347\232\204\346\243\213\345\255\220\357\274\214\n"
"\344\270\213\345\234\250\346\243\213\347\233\230\347\233\264\347\272\277\344\270\216\346\250\252\347\272\277\347\232\204\344\272\244\345\217\211\347\202\271\344\270\212\357\274\214\n"
"\345\205\210\345\275\242\346\210\2205\345\255\220\350\277\236\347\272\277\350\200\205\350\216\267\350\203\234\343\200\202\n"
"\344\272\224\345\255\220\346\243\213\345\256\271\346\230\223\344\270\212\346\211\213\357"
                        "\274\214\350\200\201\345\260\221\347\232\206\345\256\234\357\274\214\n"
"\350\200\214\344\270\224\350\266\243\345\221\263\346\250\252\347\224\237\357\274\214\345\274\225\344\272\272\345\205\245\350\203\234\357\274\233\n"
"\344\270\215\344\273\205\350\203\275\345\242\236\345\274\272\346\200\235\347\273\264\350\203\275\345\212\233\357\274\214\n"
"\346\217\220\351\253\230\346\231\272\345\212\233\357\274\214\350\200\214\344\270\224\345\257\214\345\220\253\345\223\262\347\220\206\357\274\214\n"
"\346\234\211\345\212\251\344\272\216\344\277\256\350\272\253\345\205\273\346\200\247\343\200\202", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Gamerules: public Ui_Gamerules {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GAMERULES_H
