#ifndef _PEOPLEPLAYER_H_
#define _PEOPLEPLAYER_H_
#include <cstring>
#include <iostream>
#include <cstdlib>
#include "Chesser.h"
//�����
class Peopleplayer:public Chesser 
{
	public:
		//��� 
		Peopleplayer(int Color, string Name);
		//��һ���� 
		Chesser GiveNextChess(const int Chesspadstate[15][15]);
};
#endif
